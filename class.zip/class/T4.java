
//Error1

/*public class T3
{
  private int data;
  
  private void msg()
  {
  System.out.println("CDAC");
  }
}
class T4
{
  public static void main(String argd[])
  {
  T3 t=new T3();
  t.data=40;
  System.out.println(t.data);
  t.msg();
  }
}*/

//Error2
/*class T3
{
  private int data;
  
  public void msg()
  {
  System.out.println("CDAC");
  }
}
class T4
{
  public static void main(String argd[])
  {
  T3 t=new T3();
  t.data=40;
  System.out.println(t.data);
  t.msg();
  }
}*/

//Solution1
/*class T3
{
  public int data;
  
  public void msg()
  {
  System.out.println("CDAC");
  }
}
class T4
{
  public static void main(String argd[])
  {
  T3 t=new T3();
  t.data=40;
  System.out.println(t.data);
  t.msg();
  }
}*/

//Solution2
/*class T3
{
  int data;
  
  void msg()
  {
  System.out.println("CDAC");
  }
}
class T4
{
  public static void main(String argd[])
  {
  T3 t=new T3();
  t.data=40;
  System.out.println(t.data);
  t.msg();
  }
}*/

//Solution3
class T3
{
  protected int data;
  
  public void msg()
  {
  System.out.println("CDAC");
  }
}
class T4
{
  public static void main(String argd[])
  {
  T3 t=new T3();
  t.data=40;
  System.out.println(t.data);
  t.msg();
  }
}