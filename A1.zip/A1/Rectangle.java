public class Rectangle
{
public static void main(String args[]) 
{
  float w=5.6f;
  float h=8.5f;
  float perimeter = 2 * (w+h);
  float area = w*h ;

  System.out.print("Perimeter is 2*(5.6+8.5)= ");
  System.out.format("%.2f",perimeter);
  System.out.println();
  System.out.print("Area is 5.6*8.5 = ");
  System.out.format("%.2f",area);
    }
}

