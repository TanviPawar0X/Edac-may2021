//Constructor

//Method1
/*class Cake
{
  int id;
  String name;
  
  Cake()//default constructor
  {
	int sum=0;
	int counter=0;
  }
  
  Cake(int i,String n)//Parametrise constructor
  {
	  id=i;
	  name=n;
  }
  
  /*void getdata(int i,String n)
  {
  id=i;
  name=n;
  }*/
  
  /*void show()
  {
	System.out.println(id+" "+name);
  }  
  
  
  public static void main(String args[])
  {
    Cake c=new Cake();//Constructor get executed
	//c.getdata(1,"choco");
	c.show();
  }
}*/

/* //Error if all parameters not provided
class Cake
{
  int id;
  String name;
  
  Cake()//default constructor
  {
	int sum=0;
	int counter=0;
  }
  
  Cake(int i,String n)//Parametrise constructor
  {
	  id=i;
	  name=n;
  }
  
  void show()
  {
	System.out.println(id+" "+name);
  }  
  
  
  public static void main(String args[])
  {
    Cake c=new Cake(111);//Constructor get executed
	//c.getdata(1,"choco");
	c.show();
  }
}*/

//Method2
class Cake
{
  int id;
  String name;
  
  Cake()//default constructor
  {
	int sum=0;
	int counter=0;
  }
  
  Cake(int i,String n)//Parametrise constructor
  {
	  id=i;
	  name=n;
  }
  
  void show()
  {
	System.out.println(id+" "+name);
  }  
  
  
  public static void main(String args[])
  {
    Cake c=new Cake(11,"mango");//Constructor get executed
	//c.getdata(1,"choco");
	c.show();
  }
}