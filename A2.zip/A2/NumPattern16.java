public class NumPattern16
{
public static void main(String[] args)
{
int i,j;
for(i=1;i<=5;i++)
{ 
int k=5;
 for(j=1;j<=i;j++)
 { 
   System.out.print(k+" ");
   k--;
  }
  System.out.println();
}
} 
}