import java.util.*;
class Array8
{
public static void main(String[] args)
{
int a[]=new int[6];
int sum=1;

  for(int i=0;i<a.length;i++)
  {
	a[i]=sum*sum;
	++sum;	
	}
  for(int i=0;i<a.length;i++)
  {
   System.out.print(a[i]+" ");
   }
}
}