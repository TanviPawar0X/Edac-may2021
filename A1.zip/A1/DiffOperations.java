class DiffOperations
{
public static void main(String args[])
{
System.out.println("a. -5+8*6");
System.out.println("b. (55+9)%9");
System.out.println("c. 20+-3*5/8");
System.out.println("d. 5+15/3*2-8%");

int a=-5+8*6;
int b=(55+9)%9;
int c=20+-3*5/8;
int d=5+15/3*2-8%3;                             
System.out.println(""+a);
System.out.println(""+b);
System.out.println(""+c);
System.out.println(""+d);
}
}