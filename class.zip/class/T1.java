class T
{
public void display()
{
System.out.println("hello");
}
public void show()
{
System.out.println("CDAC!!");
}
}
class T1
{
public static void main(String args[])
{
T t1=new T();
t1.display();
t1.show();
}
}
