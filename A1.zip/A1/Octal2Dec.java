import java.util.*;
public class Octal2Dec
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.print("Input any Octal number: ");
  int n=sc.nextInt();

int rem=0;
int d=0,c=0;
while(n!=0)
{
rem=n%10;
n/=10;
d=d+rem*(int)Math.pow(8,c++);
}
System.out.println("Decimal number: "+d);

    }
}


