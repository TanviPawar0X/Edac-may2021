import java.util.*;
class B1
{
 int[] id=new int[5];
 static int j=0;
 String[] name=new String[5];
 int[] cost=new int[5];
 int m;
 void input(int i,String n,int c)
 {
  id[j]=i;
  name[j]=n;
  cost[j]=c;
  ++j;
  System.out.println(cost[0]);
 }
 int input1()
 {
	 for(int k=0;k<4;k++)
	{
		if(cost[k+1]>cost[k])
		{
			m=cost[k+1];
		}
	}
	return m;
 }
 
 void display()
 {
	for(int k=0;k<5;k++)
	{
		if(cost[k]==m)
		{
         System.out.println(id[k]+" "+name[k]+" "+cost[k]);
		}
    }
 }
}
class Book
{
 public static void main(String[] args)
 {
  Scanner sc=new Scanner(System.in);
  B1 b=new B1();
  
  for(int k=0;k<5;k++)
  {
    int a=sc.nextInt();
    sc.nextLine();
    String s=sc.nextLine();
    int c=sc.nextInt();
    b.input(a,s,c);
  }
  b.input1();
  b.display();
}
}
 