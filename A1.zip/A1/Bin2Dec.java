import java.util.*;
public class Bin2Dec
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.print("Input a binary number: ");
  int n=sc.nextInt();

int rem=0;
int d=0,c=0;
while(n!=0)
{
rem=n%10;
n/=10;
d=d+rem*(int)Math.pow(2,c++);
}
System.out.println("Decimal number: "+d);

    }
}


