/* //Method1
class calculate
{
  static int cube(int x)
  {
   int r=x*x*x;
   return r;
  }
  public static void main(String args[])
  {
    int res=cube(3);
	System.out.println(res);
  }
}*/

/*//Method2
class calculate
{
  static int cube(int x)
  {
   int r=x*x*x;
   return r;
  }
  public static void main(String args[])
  {
    int res=calculate.cube(3);
	System.out.println(res);
  }
}*/

//Method3
class calculate
{
  static int cube(int x)
  {
   int r=x*x*x;
   return r;
  }
  public static void main(String args[])
  {
    //int res=calculate.cube(3);
	System.out.println(calculate.cube(3));
  }
}
