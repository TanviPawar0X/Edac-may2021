class Flag
{
public static void main(String args[]) 
{
 int i,j;
 for(i=1;i<=9;i++)
{
  if(i%2!=0)
  {
   System.out.println("* * * * * * ===================================");
   }
   else
   {
   System.out.println(" * * * * *  ===================================");
   }
}
  for(i=1;i<=6;i++)
  {
   System.out.println("===============================================");
   }
}
}
