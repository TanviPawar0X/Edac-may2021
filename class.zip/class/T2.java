//Error
/*public class T2
{
  int data;
  public void display()
  {
  data=40;
  T2 t=new T2();
  System.out.println(data);
  }
}*/

//Solution1
/*public class T2
{
   static int data;
  public void display()
  {
  data=40;
  T2 t=new T2();
  System.out.println(data);
  }
}*/

//Solution2
public class T2
{
  private int data;
  public void display()
  {
  data=40;
  T2 t=new T2();
  System.out.println(data);
  }
}