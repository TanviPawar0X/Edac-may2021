import java.util.*;
public class Dec2Hexa
{
public static void main(String args[])
{
Scanner in = new Scanner(System.in);
int rem;
String hn="";
char h[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
System.out.print("Input a decimal number: ");
int dn = in.nextInt();
while(dn>0)
{
   rem = dn%16;
   hn = h[rem] + hn;
   dn = dn/16;
 }
    System.out.print("Hexadecimal number is : "+hn);         
    }
}
