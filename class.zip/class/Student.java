import java.util.*;
class Student1
{
 int rollno;
 String name;
 int marks;
 void input()
 {
  Scanner sc=new Scanner(System.in);
  rollno=sc.nextInt();
  sc.nextLine();
  name=sc.nextLine();
  marks=sc.nextInt();
 }
 void display()
 {
  System.out.println(rollno+" "+name+" "+marks);
 }
 
}
class Student
{
 public static void main(String[] args)
 {
 Student1 s=new Student1();
 Student1 s1=new Student1();
 s.input();
 s1.input();
 s.display();
 s1.display();
 
}
}
 