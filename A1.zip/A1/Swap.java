import java.util.*;
class Swap
{
public static void main(String args[]) 
{
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter two values: ");
 int n1=sc.nextInt();
 int n2=sc.nextInt();
 System.out.println("Before Swap: "+n1+" "+n2); 
 n1=n1+n2;
 n2=n1-n2;
 n1=n1-n2;
 System.out.println("After Swap: "+n1+" "+n2);
}
}
