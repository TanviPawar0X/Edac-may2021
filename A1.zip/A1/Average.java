import java.util.*;
public class Average
{
public static void main(String args[]) 
{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter three numbers:");  
  int n1=sc.nextInt();
  int n2=sc.nextInt();
  int n3=sc.nextInt();
  int avg;
  avg=(n1+n2+n3)/3;
  System.out.println("Average = "+avg);
}
}

