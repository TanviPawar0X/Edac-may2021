class Rectangle
{
 int length=10;
 int breadth=20;
 
 void getdata(int x,int y)
 {
   length=x;
   breadth=y;
 }
 int area()
 {
	 int area=length*breadth;
	 return area;
 }
 void display()
 {
	System.out.println("Area of Rectangle: ");
 }
 
 public static void main(String[] args)
 {
   Rectangle obj=new Rectangle();
   obj.display();
   obj.getdata(10,20);
  
   System.out.println(obj.area());   
 }
}