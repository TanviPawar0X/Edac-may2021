class Pyramid1
{
public static void main(String args[])
{
int i,j,k;
for(i=1;i<=9;i++)
   {
    for(j=9;j>=1;j--)
    {
     if(j>i)
      {
          System.out.print(" ");
        }
      else
      {
       System.out.print(i+" ");
        }
      }
        System.out.println();
      }
}
}

