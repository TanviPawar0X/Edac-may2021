import java.util.Scanner;
class Product
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);

System.out.println("Input first number: ");
int n1=sc.nextInt();
System.out.println("Input second number: ");
int n2=sc.nextInt();

int p=n1*n2;
System.out.println(n1+"x"+n2+"="+p);

}
}