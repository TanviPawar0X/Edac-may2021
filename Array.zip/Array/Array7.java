import java.util.*;
class Array7
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter Array size: ");
int c=sc.nextInt();

int a1[]=new int[c+1];

System.out.println("Enter Array1: ");
  for(int i=0;i<c;i++)
  {
   a1[i]=sc.nextInt();
   }
  System.out.println();
  
  int i;
  int x=0;
  int count1=0,count2=0;
  for(i=0;i<c;i++)
  {
   if(a1[i]<a1[i+1])
   {
	x=1;
    ++count1;	
   }
  }

   if(count1==c-1) 
   {
	   System.out.println("Ascending array");
   }
   else
   {
	   for(i=0;i<c;i++)
       {
        if(a1[i]>a1[i+1])
        {
	    x=2;
        ++count2;	
        }
       }
	if(count2==c)
   {
	System.out.println("Descending array");	
   }
   else
   {
	System.out.println("Random array");	 
   }
   }
   	
   
}
}
