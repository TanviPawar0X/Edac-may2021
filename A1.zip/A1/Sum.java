import java.util.*;
class Sum
{
public static void main( String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter 1st number= ");
int i=sc.nextInt();
System.out.println("Enter 2nd number = ");
int j=sc.nextInt();
int k=i+j;
System.out.println("Sum= "+k);
}
}