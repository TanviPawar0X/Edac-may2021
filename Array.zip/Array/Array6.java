class Array6
{
public static void main(String[] args)
{
/*Scanner sc=new Scanner(System.in);
System.out.println("Enter Array size: ");
int c=sc.nextInt();

int a[]=new int[c];
int b[]=new int[c-1];
int sum;
System.out.println("Enter Array: ");
  for(int i=0;i<c;i++)
  {
   a[i]=sc.nextInt();
  }
  System.out.println();*/
  int a[]={5,14,35,89,140};
  int b[]=new int[a.length-1];
  int sum;
  int j=0;
  System.out.println("Average of 3 consecutive integers: ");
  for(int i=0;i<a.length-2;i++)
  {
   if(i<a.length-2)
   {
	   
	   if(j==0)
	   {
        sum=a[j]+a[++j]+a[++j];
        b[i]=sum/3;
       }
       else
       {
       j=j-1;
	   sum=a[j]+a[++j]+a[++j];
       b[i]=sum/3;
	   }
   }
   else
   {
	   continue;
   }
  }
  for(int i=0;i<b.length-1;i++)
   {
   System.out.print(b[i]+" ");
   }
  System.out.println();
  
}
}