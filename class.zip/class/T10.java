//Error1
/*class T9
{
 private int id;
 private String name;
 private static int total;
 
 void getdata(int id1, String name1,int t)
 {
    id=id1;
    name=name1;
	total=t;
 }
 void display()
 {
    System.out.println(id+" "+name+" "+t);
 }
 
}
class T10
{
  public static void main(String argd[])
  {
    T7 t=new T7();
	t.getdata(1,"Tan",10);
	t.display();
	T7 t1=new T7();     //Separately saving data
	t1.getdata(2,"Tin",20);
	t1.display();
	t.display();
  }
}*/

//Error2
class T9
{
 private int id;
 private String name;
 static int total;
 
 void getdata(int id1, String name1,int t)
 {
    id=id1;
    name=name1;
	total=t;
 }
 void display()
 {
    System.out.println(id+" "+name+" "+total);
 }
 
}
class T10
{
  public static void main(String argd[])
  {
    T9 t=new T9();
	t.getdata(1,"Tan",10);
	t.display();
	T7 t1=new T7();     //Separately saving data
	t1.getdata(2,"Tin",20);
	t1.display();
	t.display();
  }
}