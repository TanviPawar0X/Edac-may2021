import java.util.*;
public class Bin2Octal
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.print("Input a binary number: ");
  int n=sc.nextInt();

int rem=0;
int d=0,c=0;
while(n!=0)
{
rem=n%10;
n/=10;
d=d+rem*(int)Math.pow(2,c++);
}

int[] r=new int[100];
int i=1;
while(d!=0)
{
r[i++]=d%8;
d/=8;
}
System.out.println("Octal number is: ");
for(int j=i-1;j>0;j--)
{
  System.out.print(r[j]);
    }
}
}
