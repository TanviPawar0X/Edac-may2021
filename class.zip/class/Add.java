//double function overloading
class op
{
  static int sum(int i,int j)
  {
   return i+j;
  }
  static float sum(float i,float j)
  {
   return i+j;
  }
  static void show(int res)
  {
	System.out.println(res);
  }
  static void show1(float res)
  {
	System.out.println(res);
  }
}
class Add
{
  public static void main(String args[])
  {
  int r=op.sum(11,12);
  op.show(r);
  float r1=op.sum(11.2f,22.3f);
  op.show1(r1);
  }
}

//Using double int float 
/*class op
{
  static int sum(int i,int j)
  {
   return i+j;
  }
  static double sum(int i,float j)
  {
   return i+j;
  }
  static void show(int res)
  {
	System.out.println(res);
  }
  static void show1(double res)
  {
	System.out.println(res);
  }
}
class Add
{
  public static void main(String args[])
  {
  int r=op.sum(11,12);
  op.show(r);
  double r1=op.sum(11,22.3f);
  op.show1(r1);
  }
}*/
