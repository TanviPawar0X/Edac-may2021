
class T5
{
 private int id;
 private String name;
 
 void getdata(int id1, String name1)
 {
    id=id1;
    name=name1;
 }
 void display()
 {
    System.out.println(id+" "+name);
 }
 
}
class T6
{
  public static void main(String argd[])
  {
    T5 t=new T5();
	t.getdata(1,"Tan");
	t.display();
	t.getdata(2,"Tin");  //Overlapping data-loss of last data
	t.display();
  }
}