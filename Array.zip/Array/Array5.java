import java.util.*;
class Array5
{
public static void main(String[] args)
{
int a1[]={23,60,94,3,102,22};
int b1[]={42,16,74,1,2,3,47,88};
int count=a1.length+b1.length;
int j=0,k=0;
  for(int i=0;i<=count;i++)
  {
	if(i%2==0)
	{
		if(j<a1.length)
		{
		System.out.print(a1[j]+" ");
		++j;
		}
		else
		{
			continue;
		}
	}
	else
	{
	if(k<b1.length)
	{
		System.out.print(b1[k]+" ");
    ++k;
	}
	else
	{
		continue;
	}
	}
  }
}
}