import java.util.*;
class Array9
{
public static void main(String[] args)
{
int a[]={24,54,31,16,82,45,67};
int l=0,k=0,m=0;
  for(int i=0;i<a.length-1;i++)
  {
  if(a[i]>a[i+1])
  {
	l=a[i];	
   }
  }
  for(int i=0;i<a.length-1;i++)
  {
  if(a[i]>a[i+1] && a[i]!=l)
  {
	k=a[i];	
   }
  }
  for(int i=0;i<a.length-1;i++)
  {
  if(a[i]>a[i+1] && a[i]!=l && a[i]!=k)
  {
	m=a[i];	
   }
  }
  System.out.print("Third largest number: ");
  System.out.print(m);
}
}