class T7
{
 private int id;
 private String name;
 
 void getdata(int id1, String name1)
 {
    id=id1;
    name=name1;
 }
 void display()
 {
    System.out.println(id+" "+name);
 }
 
}
class T8
{
  public static void main(String argd[])
  {
    T7 t=new T7();
	t.getdata(1,"Tan");
	t.display();
	T7 t1=new T7();     //Separately saving data
	t1.getdata(2,"Tin");
	t1.display();
  }
}