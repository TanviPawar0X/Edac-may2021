import java.util.*;
class BankAccount
{
    int id;
	String name;
	float balance=0;
	
	float amount;
	
	void details(int i, String n,float b)
	{
		id=i;
		name=n;
	    balance=b;
		System.out.println("Name:"+name+" Id no:"+id+" Balance:"+balance);
	}
		
    void self()
	{
        System.out.println("Hello!!! Welcome to the Deposit & Withdrawal Machine");
    }  
    void deposit()
	{
	    Scanner sc=new Scanner(System.in);
  
		System.out.println("Enter amount to be Deposited: ");
		amount=sc.nextFloat();
		
        balance += amount;
        System.out.println("Amount Deposited:"+amount);
	}
  
    void withdraw()
	{
	    Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter amount to be Withdrawn: ");
		amount=sc.nextFloat();
		
        if(balance>=amount)
		{
            balance-=amount;
            System.out.println("You Withdrew:"+amount);
	    }
        else
		{
            System.out.println("Insufficient balance");
	    }
    }
    void display()
	{
        System.out.println("Net Available Balance="+balance);
	} 
}
class Bank
{
 public static void main(String args[])
 {
	 BankAccount s=new BankAccount();
	 int x;
	 String y;
	 float z;
	 Scanner sc=new Scanner(System.in);
	    System.out.println("Enter ID: ");
		x=sc.nextInt();
		
		sc.nextLine();
		System.out.println("Enter your name");
		y=sc.nextLine();
		
		System.out.println("Enter amount balance");
		z=sc.nextInt();
		if(z<1000f)
		{
			System.out.println("Minimum balance need to be Rs 1000");
		}
		else
		{
			s.details(x,y,z);
			System.out.println("Choose a number from the list:");
			System.out.println("1. Deposite cash");
			System.out.println("2. Check balance");
			System.out.println("3. Withdraw money");
			System.out.println("4. Exit");
			int option=sc.nextInt();
			switch(option)
			{
			case 1:
			s.deposit();
			s.display();
			break;
			
			case 2:
			s.display();
			break;
			
			case 3:
			s.withdraw();
			s.display();
			break;
			
			case 4:
			break;
			
			default:
			System.out.println("Wrong input");
			}
		}
		
  }
 }