import java.util.*;
public class Dec2Octal
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.print("Input a Decimal Number: ");
  int n1=sc.nextInt();
  int[] rem=new int[100];
int i=1;
while(n1!=0)
{
rem[i++]=n1%8;
n1/=8;
}

System.out.println("Octal number is: ");
for(int j=i-1;j>0;j--)
{
  System.out.print(rem[j]);
}
    }
}


