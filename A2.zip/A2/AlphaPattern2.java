class AlphaPattern2
{
public static void main(String args[])
{
int a=64, i,j;
for(i=1;i<=5;i++)
{
 for(j=1;j<=i;j++)
 { 
   System.out.print((char)(a+j)+" ");
  }
  System.out.println();
}
}
}

