import java.util.*;
class Data
{
 int[] id=new int[5];
 static int j;
 String[] name=new String[5];
 String[] designation=new String[5];
 String m="Manager";
 void input(int i,String s,String d)
 {
  id[j]=i;
  name[j]=s;
  designation[j]=d;
  ++j;
 }
 void display()
 {
	for(int k=0;k<5;k++)
	{
		boolean x=(designation[k]==m)?true:false;
		if(x==true)
		{
		System.out.println(id[k]+" "+name[k]+" "+designation[k]);
		}
    }
 }
}
class Employee
{
 public static void main(String[] args)
 {
  Scanner sc=new Scanner(System.in);
  Data b=new Data();
  
  for(int k=0;k<5;k++)
  {
    int a=sc.nextInt();
    sc.nextLine();
    String s=sc.nextLine();
    String d=sc.nextLine();
    b.input(a,s,d);
	b.display();
  }
  
}
}
 