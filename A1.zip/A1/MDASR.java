import java.util.Scanner;
class MDASR
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Input first number: ");
int n1=sc.nextInt();
System.out.println("Input second number: ");
int n2=sc.nextInt();
int d=n1/n2;
int m=n1*n2;
int a=n1+n2;
int s=n1-n2;
int r=n1%n2;                             
System.out.println(n1+"+"+n2+"="+a);
System.out.println(n1+"-"+n2+"="+s);
System.out.println(n1+"x"+n2+"="+m);
System.out.println(n1+"/"+n2+"="+d);
System.out.println(n1+"mod"+n2+"="+r);
}
}